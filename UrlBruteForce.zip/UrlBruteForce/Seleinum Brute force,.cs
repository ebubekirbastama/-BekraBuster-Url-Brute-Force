﻿using EbubekirBastamatxtokuma;
using System;
using System.Windows.Forms;
using OpenQA.Selenium.Chrome;
using System.Threading;

namespace UrlBruteForce
{
    public partial class Seleinum_Brute_force_ : Form
    {
        public Seleinum_Brute_force_()
        {
            InitializeComponent();
        }
        OpenFileDialog op; ChromeDriver drv; string url;
        private void button2_Click(object sender, EventArgs e)
        {
            op = new OpenFileDialog();
            if (op.ShowDialog() == DialogResult.OK)
            {
                BekraTxtOkuma.Txtİmport(op.FileName.ToString(), listBox1, false);
              
            }
            else
            {
                MessageBox.Show("Lütfen Listeyi Ekleyiniz.", "Ebubekir Bastama");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            drv = new ChromeDriver();
            //https://www.ebubekirbastama.com/index.php

            url = textBox1.Text;
            drv.Navigate().GoToUrl(url);
            Thread.Sleep(3000);
            int globaldgr = drv.PageSource.Length;

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                url = textBox1.Text + "/" + listBox1.Items[i].ToString();
                drv.Navigate().GoToUrl(url);
                Thread.Sleep(3000);

                int globaldgr1 = drv.PageSource.Length;
                if (globaldgr==globaldgr1)
                {
                    richTextBox1.AppendText("Site Aynı" + globaldgr1 + "\r");
                }
                else
                {
                    richTextBox1.AppendText("Site Farkı" + globaldgr1 + "\r");
                }

            }
        }
    }
}

﻿using System.Net.Http;
using System.Threading.Tasks;

namespace UrlBruteForce
{
    public class attack
    {

        public static async Task<string> RequestCode(string uri)
        {
            var httpClient = new HttpClient();
            var response = await httpClient.GetAsync(uri);
            return response.ToString().Split(',')[0].Split(':')[1].ToString();
        }
        public static async Task<string> RequestText(string uri)
        {
            var httpClient = new HttpClient();
            var response = await httpClient.GetAsync(uri);
            return response.ToString();
        }
    }
}

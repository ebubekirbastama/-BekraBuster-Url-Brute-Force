﻿using BekraGobuster;
using EbubekirBastamatxtokuma;
using System;
using System.Threading;
using System.Windows.Forms;


namespace UrlBruteForce
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            CheckForIllegalCrossThreadCalls = false;
            InitializeComponent();
        }
        Thread th; OpenFileDialog op; string url;
        private void button1_Click(object sender, EventArgs e)
        {
            th = new Thread(basla);th.Start();
        }

        private async void basla()
        {
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                try
                {
                    url = textBox1.Text + "/" + listBox1.Items[i].ToString();
                    string cevap = await Attack.RequestCode(url);
                    richTextBox1.AppendText(listBox1.Items[i].ToString() + "(" + cevap + ")\n");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message,"Ebubekir Bastama");
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            op= new OpenFileDialog();
            if (op.ShowDialog()==DialogResult.OK)
            {
               BekraTxtOkuma.Txtİmport(op.FileName.ToString(),listBox1,false);
                label1.Text = "Payload Adedi :" + listBox1.Items.Count;
            }
            else
            {
                MessageBox.Show("Lütfen Listeyi Ekleyiniz.","Ebubekir Bastama");
            }
        }
    }
}
//Nuget Paketi
//https://www.nuget.org/packages/HttpClient